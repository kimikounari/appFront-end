import React, { useEffect,useState,useRef} from 'react';
import io from 'socket.io-client';
import './App.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {faPaperPlane} from "@fortawesome/free-solid-svg-icons"
import {faComment} from "@fortawesome/free-solid-svg-icons";
import {faChevronLeft} from "@fortawesome/free-solid-svg-icons";
let socket;
export const Chat = () => {
    const componentRef = useRef(null);
    const [chatmessage, chatmessageSet] = useState('');
    const [receivechatmessage, receivechatmessageSet] = useState([]);
    useEffect(() => {
        socket= io('https://trial-app-comu.onrender.com/chat'); 
        socket.on('connect', () => {
        });
       socket.on('chatMessage', (msg) => {
          receivechatmessageSet((prevItems) => [...prevItems, msg]);
          chatmessageSet('');
        });
        return () => {
          socket.disconnect();
        };
      }, []);

      const chatmessageSend = (e) => {
        socket.emit('chatMessage', chatmessage);
      };

      const chatmessageUpdate = (e) => {
        chatmessageSet(e.target.value);
      };

      const [chatAreaStatus, setChatAreaStatus] = useState(false);

      const chatareaShowHide = () => {
        setChatAreaStatus(!chatAreaStatus);
      }
    
  return (
    <div>
    <div className="App">
      <div onClick={chatareaShowHide} className='chat-area-status-btn'>
        {chatAreaStatus ?  <FontAwesomeIcon icon={faChevronLeft} className='chat-area-status-icon'/>: <FontAwesomeIcon icon={faComment} className='chat-area-status-icon'/>}
        {chatAreaStatus ?  <p className='chat-area-status-text'>閉じる</p>: <p className='chat-area-status-text'>チャット</p>}
      </div>
      <div className={chatAreaStatus ? "chat-area" : "chat-area-none"}>
        <ul ref={componentRef} className='message'>
          {receivechatmessage.map((item, index) => (
            <li key={index} className='chat-message'>{item}</li>
          ))}
        </ul>
        <div className='send-area'>
          <input  type="text" value={chatmessage} onChange={chatmessageUpdate} className='send-field'></input>
          <button onClick={chatmessageSend} className='send-btn'><FontAwesomeIcon icon={faPaperPlane} className='chat_send_icon'/></button>
        </div>
      </div>
    </div>
    </div>
  )
}


