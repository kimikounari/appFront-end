import { Chat } from './Chat';
import { UnityDisplay } from './Unity';
import React, { useState, useRef, useEffect, Component } from 'react';
import './App.css';
import Audiochat from './Audiochat';
import './App.css';
import { faVideo } from '@fortawesome/free-solid-svg-icons';
import io from 'socket.io-client';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faMicrophone } from "@fortawesome/free-solid-svg-icons"
import { faMicrophoneSlash } from "@fortawesome/free-solid-svg-icons"
import axios from 'axios';
function App() {
  //ビデオチャット機能、後で別ファイルに移植
  const roomid = "56564";
  const socket = io('https://trial-app-comu.onrender.com/video_chat_socket');//デプロイ時変更
  let myPeer;
  const myVideo = document.createElement('video');
  myVideo.muted = true;
  const videoWeap = useRef([]);
  const peers = {}
  let myVideoStream

  //ログイン機能
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [loginPass, setLoginPass] = useState('');


  //ミュートボタン管理
  const buttonRef = useRef(null);
  const buttonNoneRef = useState(null);
  const buttonText = useRef(null);
  const buttonTextAudio = useRef(null);

  const connectToNewUser = (userId, stream) => {
    const call = myPeer.call(userId, stream);
    const video = document.createElement('video');
    call.on("stream", (userVideoStream) => {
      addVideoStresm(video, userVideoStream);
    });
    call.on("close", () => {
      video.remove();
    })
    peers[userId] = call;
  }

  const addVideoStresm = (video, stream) => {
    video.srcObject = stream;
    video.addEventListener("loadedmetadata", () => {
      video.play();
    })
    videoWeap.current.appendChild(video);
  }

  const functionVideoChat = () => {
    myPeer = new window.Peer()

    navigator.mediaDevices.getUserMedia({
      video: true,
      audio: false,
    })
      .then((stream) => {
        myVideoStream = stream;
        addVideoStresm(myVideo, stream);
        myPeer.on("call", (call) => {
          call.answer(stream);
          const video = document.createElement("video");
          call.on("stream", userVideoStream => {
            addVideoStresm(video, userVideoStream);
          })
          const userId = call.peer;
          peers[userId] = call;
        })

        socket.on("user-connected", (userId) => {
          console.log("userId=", userId);
          connectToNewUser(userId, myVideoStream);
        })
      });

    myPeer.on("disconnected", (userId) => {
      console.log("disconnected=" + userId);
    })

    myPeer.on("open", userId => {
      socket.emit("join-room", roomid, userId);
    })

    socket.on("user-disconnected", (userId) => {
      if (peers[userId]) peers[userId].close();
    })
  }



  const playStop = (e) => {
    const enabled = myVideoStream.getVideoTracks()[0].enabled;
    if (enabled) {
      myVideoStream.getVideoTracks()[0].enabled = false
      //e.classList.add("active")
      //myVideoStream.getVideoTracks()[0].enabled =  false
    } else {
      //e.classList.remove("active")
      myVideoStream.getVideoTracks()[0].enabled = true
    }
  }

  const leaveVideo = (e) => {
    socket.disconnect();
    myPeer.disconnect();
    myPeer = null;
    const videos = document.getElementsByTagName("video")
    console.log(videos);
    for (let i = videos.length - 1; i >= 0; --i) {
      videos[i].remove();
    }
  }

  function redirectToExternalURL(url) {
    window.open(url, '_blank');
  }

  //ログイン機能
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('http://127.0.0.1:8080/api/custom-model/', {
        name: name,
        _password: password
      });

      if (response.status === 201) {
        console.log("Data created successfully", response.data);
      } else if (response.status === 400) {
        console.error("Data with the same name and password already exists", response.data);
      } else {
        console.error("Error creating data", response);
      }

    } catch (error) {
      console.error("There was an error sending the POST request", error);
    }
  };

  const handleRetrieve = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('http://127.0.0.1:8080/api/get-name-and-id/', {
        _password: loginPass
      });

      if (response.status === 200) {
        console.log("Data retrieved successfully", response.data);
        // ここで response.data.name と response.data.id を使用して何かを行う
      } else {
        console.error("Error retrieving data", response);
      }
    } catch (error) {
      console.error("There was an error sending the POST request", error);
    }
  };

  return (
    <div>
      <button onClick={functionVideoChat}>ビデオ通話開始</button>
      <Chat />
      <UnityDisplay />
      <Audiochat />
      <div>
        <div className='social_area'>
          <div className='main__wrap'>

          </div>
        </div>
        <div ref={videoWeap} id='video-wrap'></div>
      </div>

      <div className='login-area'>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Name"
          />
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
          />
          <button type="submit">Create</button>
        </form>

        <form onSubmit={handleRetrieve}>
          <input
            type="password"
            value={loginPass}
            onChange={(e) => setLoginPass(e.target.value)}
            placeholder="Password"
          />
          <button type="submit">Create</button>
        </form>
      </div>
    </div>
  );
}
export default App;
